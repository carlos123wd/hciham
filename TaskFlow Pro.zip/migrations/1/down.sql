
DROP INDEX idx_tasks_due_date;
DROP INDEX idx_tasks_category;
DROP INDEX idx_tasks_status;
DROP TABLE tasks;
