import z from "zod";

export const TaskSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  category: z.string(),
  amount: z.number().nullable(),
  due_date: z.string(), // ISO date string
  status: z.enum(['pending', 'done', 'upcoming']),
  notes: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateTaskSchema = z.object({
  name: z.string().min(1, "Task name is required"),
  description: z.string().optional(),
  category: z.string().min(1, "Category is required"),
  amount: z.number().optional(),
  due_date: z.string(), // ISO date string
  status: z.enum(['pending', 'done', 'upcoming']),
  notes: z.string().optional(),
});

export const UpdateTaskSchema = CreateTaskSchema.partial().extend({
  id: z.number(),
});

export type Task = z.infer<typeof TaskSchema>;
export type CreateTask = z.infer<typeof CreateTaskSchema>;
export type UpdateTask = z.infer<typeof UpdateTaskSchema>;

export const FilterType = z.enum(['all', 'today', 'week', 'month', 'overdue']);
export type FilterType = z.infer<typeof FilterType>;

export const TaskStats = z.object({
  totalTasks: z.number(),
  completedTasks: z.number(),
  pendingPayments: z.number(),
  progressPercentage: z.number(),
});

export type TaskStats = z.infer<typeof TaskStats>;
