import { Hono } from "hono";
import { cors } from "hono/cors";
import { CreateTaskSchema, UpdateTaskSchema } from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

app.use('*', cors());

// Get all tasks with optional filtering
app.get('/api/tasks', async (c) => {
  const filter = c.req.query('filter') || 'all';
  
  let sql = 'SELECT * FROM tasks';
  const params: any[] = [];
  
  const now = new Date();
  const today = now.toISOString().split('T')[0];
  const weekStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay());
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  
  switch (filter) {
    case 'today':
      sql += ' WHERE due_date = ?';
      params.push(today);
      break;
    case 'week':
      sql += ' WHERE due_date >= ? AND due_date <= ?';
      params.push(weekStart.toISOString().split('T')[0], today);
      break;
    case 'month':
      sql += ' WHERE due_date >= ? AND due_date <= ?';
      params.push(monthStart.toISOString().split('T')[0], today);
      break;
    case 'overdue':
      sql += ' WHERE due_date < ? AND status != "done"';
      params.push(today);
      break;
  }
  
  sql += ' ORDER BY due_date ASC, created_at DESC';
  
  try {
    const result = await c.env.DB.prepare(sql).bind(...params).all();
    return c.json(result.results);
  } catch (error) {
    console.error('Error fetching tasks:', error);
    return c.json({ error: 'Failed to fetch tasks' }, 500);
  }
});

// Get task statistics
app.get('/api/tasks/stats', async (c) => {
  try {
    const totalResult = await c.env.DB.prepare('SELECT COUNT(*) as count FROM tasks').first();
    const completedResult = await c.env.DB.prepare('SELECT COUNT(*) as count FROM tasks WHERE status = "done"').first();
    const pendingPaymentsResult = await c.env.DB.prepare('SELECT COUNT(*) as count FROM tasks WHERE status != "done" AND amount IS NOT NULL AND amount > 0').first();
    
    const totalTasks = (totalResult as any)?.count || 0;
    const completedTasks = (completedResult as any)?.count || 0;
    const pendingPayments = (pendingPaymentsResult as any)?.count || 0;
    const progressPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
    
    return c.json({
      totalTasks,
      completedTasks,
      pendingPayments,
      progressPercentage,
    });
  } catch (error) {
    console.error('Error fetching stats:', error);
    return c.json({ error: 'Failed to fetch statistics' }, 500);
  }
});

// Create a new task
app.post('/api/tasks', async (c) => {
  try {
    const body = await c.req.json();
    const validatedData = CreateTaskSchema.parse(body);
    
    const sql = `
      INSERT INTO tasks (name, description, category, amount, due_date, status, notes)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    
    const result = await c.env.DB.prepare(sql)
      .bind(
        validatedData.name,
        validatedData.description || null,
        validatedData.category,
        validatedData.amount || null,
        validatedData.due_date,
        validatedData.status,
        validatedData.notes || null
      )
      .run();
    
    if (result.success) {
      const newTask = await c.env.DB.prepare('SELECT * FROM tasks WHERE id = ?')
        .bind(result.meta.last_row_id)
        .first();
      return c.json(newTask, 201);
    } else {
      return c.json({ error: 'Failed to create task' }, 500);
    }
  } catch (error) {
    console.error('Error creating task:', error);
    return c.json({ error: 'Invalid task data' }, 400);
  }
});

// Update a task
app.put('/api/tasks/:id', async (c) => {
  try {
    const id = parseInt(c.req.param('id'));
    const body = await c.req.json();
    const validatedData = UpdateTaskSchema.parse({ ...body, id });
    
    const updates: string[] = [];
    const params: any[] = [];
    
    if (validatedData.name !== undefined) {
      updates.push('name = ?');
      params.push(validatedData.name);
    }
    if (validatedData.description !== undefined) {
      updates.push('description = ?');
      params.push(validatedData.description);
    }
    if (validatedData.category !== undefined) {
      updates.push('category = ?');
      params.push(validatedData.category);
    }
    if (validatedData.amount !== undefined) {
      updates.push('amount = ?');
      params.push(validatedData.amount);
    }
    if (validatedData.due_date !== undefined) {
      updates.push('due_date = ?');
      params.push(validatedData.due_date);
    }
    if (validatedData.status !== undefined) {
      updates.push('status = ?');
      params.push(validatedData.status);
    }
    if (validatedData.notes !== undefined) {
      updates.push('notes = ?');
      params.push(validatedData.notes);
    }
    
    updates.push('updated_at = CURRENT_TIMESTAMP');
    params.push(id);
    
    const sql = `UPDATE tasks SET ${updates.join(', ')} WHERE id = ?`;
    
    const result = await c.env.DB.prepare(sql).bind(...params).run();
    
    if (result.success) {
      const updatedTask = await c.env.DB.prepare('SELECT * FROM tasks WHERE id = ?')
        .bind(id)
        .first();
      return c.json(updatedTask);
    } else {
      return c.json({ error: 'Failed to update task' }, 500);
    }
  } catch (error) {
    console.error('Error updating task:', error);
    return c.json({ error: 'Invalid task data' }, 400);
  }
});

// Delete a task
app.delete('/api/tasks/:id', async (c) => {
  try {
    const id = parseInt(c.req.param('id'));
    const result = await c.env.DB.prepare('DELETE FROM tasks WHERE id = ?').bind(id).run();
    
    if (result.success) {
      return c.json({ message: 'Task deleted successfully' });
    } else {
      return c.json({ error: 'Failed to delete task' }, 500);
    }
  } catch (error) {
    console.error('Error deleting task:', error);
    return c.json({ error: 'Failed to delete task' }, 500);
  }
});

// Get analytics data
app.get('/api/analytics', async (c) => {
  try {
    // Status distribution
    const statusResult = await c.env.DB.prepare(`
      SELECT status, COUNT(*) as count 
      FROM tasks 
      GROUP BY status
    `).all();
    
    // Category distribution
    const categoryResult = await c.env.DB.prepare(`
      SELECT category, COUNT(*) as count 
      FROM tasks 
      GROUP BY category
    `).all();
    
    // Monthly progress (last 6 months)
    const monthlyResult = await c.env.DB.prepare(`
      SELECT 
        strftime('%Y-%m', created_at) as month,
        COUNT(*) as total,
        SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END) as completed
      FROM tasks
      WHERE created_at >= date('now', '-6 months')
      GROUP BY strftime('%Y-%m', created_at)
      ORDER BY month ASC
    `).all();
    
    return c.json({
      statusDistribution: statusResult.results,
      categoryDistribution: categoryResult.results,
      monthlyProgress: monthlyResult.results,
    });
  } catch (error) {
    console.error('Error fetching analytics:', error);
    return c.json({ error: 'Failed to fetch analytics' }, 500);
  }
});

export default app;
