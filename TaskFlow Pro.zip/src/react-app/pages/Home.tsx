import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Plus, 
  Filter, 
  CheckSquare, 
  DollarSign, 
  TrendingUp,
  Calendar,
  BarChart3
} from 'lucide-react';
import { useTasks } from '@/react-app/hooks/useTasks';
import { FilterType } from '@/shared/types';
import StatsCard from '@/react-app/components/StatsCard';
import TaskForm from '@/react-app/components/TaskForm';
import TaskTable from '@/react-app/components/TaskTable';
import Analytics from '@/react-app/components/Analytics';

const filterOptions = [
  { value: 'all', label: 'All Tasks' },
  { value: 'today', label: "Today's Tasks" },
  { value: 'week', label: 'This Week' },
  { value: 'month', label: 'This Month' },
  { value: 'overdue', label: 'Overdue' },
];

export default function Home() {
  const { tasks, stats, loading, error, fetchTasks, createTask, updateTask, deleteTask } = useTasks();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [currentFilter, setCurrentFilter] = useState<FilterType>('all');
  const [activeTab, setActiveTab] = useState<'tasks' | 'analytics'>('tasks');

  const handleFilterChange = (filter: FilterType) => {
    setCurrentFilter(filter);
    fetchTasks(filter);
  };

  if (loading && tasks.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">TaskFlow Pro</h1>
              <p className="text-sm text-gray-500">Manage your tasks and payments efficiently</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setActiveTab('tasks')}
                  className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                    activeTab === 'tasks'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Calendar className="inline w-4 h-4 mr-1" />
                  Tasks
                </button>
                <button
                  onClick={() => setActiveTab('analytics')}
                  className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                    activeTab === 'analytics'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <BarChart3 className="inline w-4 h-4 mr-1" />
                  Analytics
                </button>
              </div>
              <button
                onClick={() => setIsFormOpen(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-all shadow-sm hover:shadow-md"
              >
                <Plus size={20} />
                Add Task
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6"
          >
            <p className="text-red-600">Error: {error}</p>
          </motion.div>
        )}

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Total Tasks"
            value={stats.totalTasks}
            icon={CheckSquare}
            color="bg-blue-500"
            delay={0}
          />
          <StatsCard
            title="Completed Tasks"
            value={stats.completedTasks}
            icon={CheckSquare}
            color="bg-green-500"
            delay={0.1}
          />
          <StatsCard
            title="Pending Payments"
            value={stats.pendingPayments}
            icon={DollarSign}
            color="bg-yellow-500"
            delay={0.2}
          />
          <StatsCard
            title="Progress"
            value={`${stats.progressPercentage}%`}
            icon={TrendingUp}
            color="bg-purple-500"
            delay={0.3}
          />
        </div>

        {/* Content */}
        {activeTab === 'tasks' ? (
          <div className="space-y-6">
            {/* Filter Controls */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-xl shadow-sm border border-gray-100 p-4"
            >
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Filter size={20} className="text-gray-400" />
                  <span className="text-sm font-medium text-gray-700">Filter by:</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {filterOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => handleFilterChange(option.value as FilterType)}
                      className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                        currentFilter === option.value
                          ? 'bg-blue-100 text-blue-700 border border-blue-200'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200 border border-transparent'
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Task Table */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <TaskTable
                tasks={tasks}
                onUpdate={updateTask}
                onDelete={deleteTask}
              />
            </motion.div>
          </div>
        ) : (
          <Analytics />
        )}
      </main>

      {/* Task Form Modal */}
      <TaskForm
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        onSubmit={createTask}
      />
    </div>
  );
}
